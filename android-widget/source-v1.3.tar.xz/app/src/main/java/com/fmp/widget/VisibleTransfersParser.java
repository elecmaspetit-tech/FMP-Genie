package com.fmp.widget;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Best-effort, READ-ONLY parser for accessibility text exposed by the *FMP APK*.
 * It never contacts FMP servers, writes to FMP, or guesses an order/transaction.
 * Screen coordinates can differ by version: a capture failure leaves saved data unchanged.
 */
public final class VisibleTransfersParser {
    private VisibleTransfersParser() {}
    public static final String[] SECTIONS = {"Favoris", "Offres reçues", "Mes offres", "En attente"};
    private static final Pattern AGE = Pattern.compile("^(1[6-9]|[2-5][0-9])(?:\\s*[0-5][0-9])?$");
    private static final Pattern MONEY = Pattern.compile("^[0-9]{1,3}(?:[, .][0-9]{3})+(?:[.,][0-9]+)?$");
    private static final Pattern BAD_NAME = Pattern.compile("^(?:i|info|n/a|g|d|nom|age|offre|fin|evaluation|iq|pfp|\u2605+|[0-9.,]+)$",Pattern.CASE_INSENSITIVE);

    public static final class Word {
        public final String text;
        public final int left, top, right, bottom;
        public Word(String text, int left, int top, int right, int bottom) {
            this.text = text == null ? "" : text.trim();
            this.left = left; this.top = top; this.right = right; this.bottom = bottom;
        }
        public int cy() { return (top + bottom)/2; }
        public int cx() { return (left + right)/2; }
    }
    public static final class Transfer {
        public final int section;
        public final String name, offer, deadline;
        public Transfer(int section, String name, String offer, String deadline) {
            this.section = section; this.name = name; this.offer = offer; this.deadline = deadline;
        }
    }
    private static String norm(String s) {
        String n = Normalizer.normalize(s == null ? "" : s, Normalizer.Form.NFD);
        return n.replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT).trim();
    }
    private static int headingSection(String text) {
        String n = norm(text);
        if (n.contains("votre liste de favoris") || n.contains("your favorites list") || n.contains("your favourites list")) return 0;
        if (n.contains("offres pour vos joueurs") || n.contains("offers for your players")) return 1;
        if (n.equals("vos offres") || n.equals("your offers")) return 2;
        if (n.contains("offres en attente") || n.contains("pending offers")) return 3;
        return -1;
    }
    public static List<Transfer> parse(List<Word> raw, int displayWidth) {
        if (raw == null || raw.isEmpty() || displayWidth < 200) return Collections.emptyList();
        List<Word> items = new ArrayList<>();
        Set<String> unique = new HashSet<>();
        for (Word w : raw) {
            if (w.text.isEmpty() || w.text.length() > 160 || w.bottom < w.top) continue;
            String key = w.text+"|"+w.left+"|"+w.top+"|"+w.right;
            if (unique.add(key)) items.add(w);
        }
        items.sort(Comparator.comparingInt((Word a)->a.top).thenComparingInt(a->a.left));
        List<Word> headings = new ArrayList<>();
        for (Word w : items) if (headingSection(w.text)>=0) headings.add(w);
        if (headings.isEmpty()) return Collections.emptyList();
        List<Transfer> out = new ArrayList<>();
        for (int h=0; h<headings.size(); h++) {
            Word heading = headings.get(h);
            int section = headingSection(heading.text);
            int stop = h+1 < headings.size() ? headings.get(h+1).top : Integer.MAX_VALUE;
            List<Word> area = new ArrayList<>();
            for (Word w : items) if (w.top>heading.bottom && w.top<stop) area.add(w);
            if (area.isEmpty()) continue;
            // Header often includes Nom / Age / Offre; calibrate from actual screen when present.
            int ageX = displayWidth * 29 / 100;
            int offerX = displayWidth * 75 / 100;
            int endX = displayWidth * 89 / 100;
            int bodyY = heading.bottom + 45;
            for (Word w: area) {
                String n = norm(w.text);
                if (w.top > heading.bottom+140) break;
                if (n.equals("age") || n.equals("age ")) ageX = w.left;
                if (n.equals("offre") || n.equals("bid")) offerX = w.left;
                if (n.equals("fin") || n.equals("end")) endX = w.left;
                if (n.equals("info") || n.equals("nom") || n.equals("name")) bodyY = Math.max(bodyY,w.bottom+3);
            }
            List<Word> ageWords = new ArrayList<>();
            for (Word w : area) {
                if (w.cy() < bodyY || !AGE.matcher(w.text).matches()) continue;
                if (w.left < displayWidth*18/100 || w.left > displayWidth*49/100) continue;
                // Group ages can include weeks; use location nearest Age header as strong signal.
                if (Math.abs(w.left-ageX)>displayWidth*13/100) continue;
                ageWords.add(w);
            }
            ageWords.sort(Comparator.comparingInt(Word::cy));
            List<Word> rowAges = new ArrayList<>();
            for (Word w : ageWords) {
                if (!rowAges.isEmpty() && Math.abs(w.cy()-rowAges.get(rowAges.size()-1).cy()) < 28) continue;
                rowAges.add(w);
            }
            for (int i=0;i<rowAges.size();i++) {
                Word current=rowAges.get(i);
                int top = i==0 ? current.cy()-65 : (current.cy()+rowAges.get(i-1).cy())/2;
                int bottom = i+1==rowAges.size() ? current.cy()+80 : (current.cy()+rowAges.get(i+1).cy())/2;
                List<Word> names = new ArrayList<>();
                List<Word> prices = new ArrayList<>();
                List<Word> endings = new ArrayList<>();
                for (Word w : area) {
                    if (w.cy()<top || w.cy()>=bottom) continue;
                    String n=norm(w.text);
                    if (w.left>=displayWidth*10/100 && w.left<current.left-8 && !BAD_NAME.matcher(n).matches()
                            && w.text.matches(".*[\\p{L}].*")) names.add(w);
                    if (w.left >= offerX-26 && w.left < endX+5) prices.add(w);
                    if (w.left >= endX-6) endings.add(w);
                }
                names.sort(Comparator.comparingInt((Word w)->w.top).thenComparingInt(w->w.left));
                StringBuilder name = new StringBuilder();
                for (Word w : names) {
                    if (w.text.length()>35) continue;
                    if (name.length()>0) name.append(' ');
                    name.append(w.text);
                }
                String player=name.toString().replaceAll("\\s+"," ").trim();
                if (player.length()<3 || player.length()>65) continue;
                String price="";
                prices.sort(Comparator.comparingInt((Word w)->w.top).thenComparingInt(w->w.left));
                for (Word w:prices) if (MONEY.matcher(w.text).matches() || norm(w.text).equals("n/a")) {price=w.text;break;}
                StringBuilder deadline=new StringBuilder();
                endings.sort(Comparator.comparingInt((Word w)->w.top).thenComparingInt(w->w.left));
                for (Word w:endings) if (w.text.matches("(?i).*\\d.*[hjmd].*") || norm(w.text).contains("vendu") || norm(w.text).contains("sold")) {
                    if (deadline.length()>0) deadline.append(' ');
                    deadline.append(w.text);
                    if(deadline.length()>24)break;
                }
                out.add(new Transfer(section,player,price,deadline.toString()));
            }
        }
        return out;
    }
}
