import com.fmp.widget.VisibleTransfersParser;
import java.util.ArrayList;
import java.util.List;

/** Execute with ./tests/run_parser_tests.sh (no Android SDK needed). */
public final class ParserTest {
    private static void add(List<VisibleTransfersParser.Word> a,String t,int x,int y) {
        a.add(new VisibleTransfersParser.Word(t,x,y,x+Math.max(18,t.length()*9),y+22));
    }
    private static void eq(Object expected,Object actual) {
        if(!expected.equals(actual))throw new AssertionError("Expected "+expected+" got "+actual);
    }
    public static void main(String[] args) {
        List<VisibleTransfersParser.Word> w=new ArrayList<>();
        add(w,"Offres pour vos joueurs",11,115);
        add(w,"Nom",117,161);add(w,"Age",205,161);add(w,"Offre",542,161);add(w,"Fin",638,161);
        add(w,"Adrian",88,216);add(w,"Joseph",88,244);add(w,"38",210,225);
        add(w,"495,289",546,245);add(w,"2j",644,212);
        add(w,"Vos Offres",10,335);
        add(w,"Nom",117,370);add(w,"Age",205,370);add(w,"Offre",540,370);
        add(w,"John",89,425);add(w,"Dionysiou",89,455);add(w,"35",209,434);
        add(w,"790,372",547,458);add(w,"Vendu",646,438);
        add(w,"Offres en attente",11,535);
        add(w,"Votre liste de favoris",10,612);
        add(w,"Nom",116,654);add(w,"Age",205,654);add(w,"Offre",539,654);add(w,"Fin",645,654);
        add(w,"Axel",90,702);add(w,"Focquet",90,740);add(w,"34",210,714);
        add(w,"2,491,547",544,740);add(w,"14h",646,704);
        add(w,"Hichem",89,818);add(w,"Becker",89,853);add(w,"37",212,832);
        add(w,"2,830,533",541,856);add(w,"1j",650,820);
        List<VisibleTransfersParser.Transfer> results=VisibleTransfersParser.parse(w,709);
        eq(4,results.size());
        eq("Adrian Joseph",results.get(0).name);
        eq(1,results.get(0).section);
        eq("495,289",results.get(0).offer);
        eq("John Dionysiou",results.get(1).name);
        eq(2,results.get(1).section);
        eq("Axel Focquet",results.get(2).name);
        eq(0,results.get(2).section);
        eq("2,491,547",results.get(2).offer);
        eq("Hichem Becker",results.get(3).name);
        eq("2,830,533",results.get(3).offer);
        List<VisibleTransfersParser.Word> unrelated=new ArrayList<>();
        add(unrelated,"Équipe / tactiques",3,10);add(unrelated,"19",203,150);
        eq(0,VisibleTransfersParser.parse(unrelated,709).size());
        eq(0,VisibleTransfersParser.parse(null,709).size());
        System.out.println("OK : 11 assertions • 4 joueurs détectés, 3 sections, aucune lecture hors transferts");
    }
}
