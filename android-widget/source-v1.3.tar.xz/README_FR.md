# FMP Mes transferts — V1.3 LIVE CAPTURE (expérimentale)

Widget Android indépendant conservé. **Lecture des joueurs et montants visibles sur la page « Offres concernant votre équipe » de l’APK officiel FMP** au moyen du partage d’application Android et d’une reconnaissance de texte *sur l’appareil* (Google ML Kit modèle embarqué).

## Mode d'emploi

1. Ouvrir **FMP Mes transferts** et appuyer sur **Démarrer lecture FMP en direct**.
2. Dans la boîte Android de partage d’écran, choisir « Une application » et **FMP officiel** si proposé ; ne pas partager tout l’écran si ce n’est pas nécessaire.
3. Ouvrir FMP et la page « Offres concernant votre équipe », puis défiler jusqu’à la liste des favoris et les offres.
4. Revenir au widget d’accueil : les lignes reconnues sont visibles et datées. Elles représentent une **dernière capture**, pas des enchères rafraîchies en arrière-plan quand FMP n’est pas visible.
5. Arrêter le partage via la notification Android ou l’application FMP Mes transferts.

## Confidentialité et limites

- Autorisation de partage explicite **pour chaque session**, notification persistante, bouton Arrêter.
- Aucune permission Accessibilité / Internet. Images analysées en mémoire uniquement ; jamais sauvegardées ni transmises.
- Seul le texte provenant de la page FMP quand des en-têtes d’offres sont reconnus est conservé, et uniquement nom, montant, fin.
- Les données reconnues peuvent être incorrectes (OCR), notamment les noms sur deux lignes et les échéances. Vérifier chaque montant dans FMP.
- L'écran FMP doit être visible pendant la capture. Le widget n'a pas d'accès direct aux données privées ni d'API officielle vérifiée.
- Aucune action d'achat/enchère n'est envoyée ; gérer les confirmations dans FMP.
- La nouvelle signature debug lors d’une compilation GitHub peut nécessiter de désinstaller la V1.2, ce qui efface les données locales de l’app.

## Compilation

Gradle 8.11.1, JDK 17, Android SDK 35. App : `com.fmp.widget`, `assembleDebug`.
