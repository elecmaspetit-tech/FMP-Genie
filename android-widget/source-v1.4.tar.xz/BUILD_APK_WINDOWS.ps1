# Construire un APK Android Debug depuis les sources (Windows + SDK Android installé).
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$SDK = if ($env:ANDROID_HOME -and (Test-Path $env:ANDROID_HOME)) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
if (-not (Test-Path $SDK)) {
    throw "SDK Android introuvable : installez Android Studio, puis SDK Manager > Android SDK Platform 35. Chemin attendu : $SDK"
}
$env:ANDROID_HOME = $SDK
$env:ANDROID_SDK_ROOT = $SDK
$Platform = Join-Path $SDK 'platforms\android-35\android.jar'
if (-not (Test-Path $Platform)) { throw "Android SDK Platform 35 absent. À installer depuis Android Studio > SDK Manager." }
$Java = Get-Command java -ErrorAction SilentlyContinue
if (-not $Java) {
    $Jbr = Join-Path $env:PROGRAMFILES 'Android\Android Studio\jbr'
    if (-not (Test-Path (Join-Path $Jbr 'bin\java.exe'))) { throw 'Java 17+ ou Android Studio JBR introuvable.' }
    $env:JAVA_HOME = $Jbr
    $env:Path = (Join-Path $Jbr 'bin') + ';' + $env:Path
}
$GradleHome = Join-Path $PSScriptRoot '.build-tools\gradle-8.11.1'
$GradleBat = Join-Path $GradleHome 'bin\gradle.bat'
if (-not (Test-Path $GradleBat)) {
    $Tools = Join-Path $PSScriptRoot '.build-tools'
    New-Item -ItemType Directory -Force -Path $Tools | Out-Null
    $Zip = Join-Path $Tools 'gradle-8.11.1-bin.zip'
    Write-Host 'Téléchargement de Gradle officiel (premier lancement)...'
    Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.11.1-bin.zip' -OutFile $Zip
    Expand-Archive -LiteralPath $Zip -DestinationPath $Tools -Force
}
Write-Host 'Compilation réelle de l’application Android...'
& $GradleBat --no-daemon :app:assembleDebug
if ($LASTEXITCODE -ne 0) { throw "Gradle a échoué avec le code $LASTEXITCODE." }
$Source = Join-Path $PSScriptRoot 'app\build\outputs\apk\debug\app-debug.apk'
$Out = Join-Path $PSScriptRoot 'FMP_Mes_Transferts_V1_debug.apk'
if (-not (Test-Path $Source)) { throw "Compilation terminée mais APK introuvable : $Source" }
Copy-Item $Source $Out -Force
Write-Host "APK réellement généré : $Out"
