package com.fmp.widget;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/** Parses on-device OCR geometry from the *visible* FMP transfer table only.
 *  Conservative by design: missing a row is preferable to saving a merged name
 *  or attributing a bid/deadline to the wrong player. Pure Java, unit tested. */
public final class VisibleTransfersParser {
    private VisibleTransfersParser() {}
    public static final String[] SECTIONS={"Favoris","Offres reçues","Mes offres","En attente"};
    private static final Pattern NAME=Pattern.compile("^[\\p{L}][\\p{L}.'’\\-]{1,29}(?:\\s+[\\p{L}][\\p{L}.'’\\-]{1,29}){0,2}$");
    private static final Pattern MONEY=Pattern.compile("^(?:[0-9]{1,3}(?:[., \\u00a0][0-9]{3})+|[0-9]{4,12})$");
    private static final Pattern DURATION=Pattern.compile("(?iu)^(?:[0-9]{1,3}\\s*(?:j|h|min|m|d)|vendu|sold|expir[ée]|termin[ée])$");
    private static final Set<String> NON_NAMES=new HashSet<>();
    static { Collections.addAll(NON_NAMES,"nom","name","age","info","offre","offres","fin","end","iq","evaluation","pfp","d","g","md","dg","mg","mc","dc","n/a","na","sold","vendu","attente","favoris","fav","joueurs","player"); }

    public static final class Word {
        public final String text;
        public final int left,top,right,bottom;
        public Word(String t,int l,int y,int r,int b){text=t==null?"":t.trim();left=l;top=y;right=r;bottom=b;}
        public int cy(){return (top+bottom)/2;}
        public int cx(){return (left+right)/2;}
        public int h(){return Math.max(1,bottom-top);}
    }
    public static final class Transfer {
        public final int section;
        public final String name,offer,deadline;
        public Transfer(int s,String n,String o,String d){section=s;name=n;offer=o;deadline=d;}
        @Override public String toString(){return "Transfer("+section+","+name+","+offer+","+deadline+")";}
    }
    private static final class NameRow {
        final List<Word> tokens=new ArrayList<>();
        int firstY=Integer.MAX_VALUE,lastY=Integer.MIN_VALUE;
        void add(Word w){tokens.add(w);firstY=Math.min(firstY,w.cy());lastY=Math.max(lastY,w.cy());}
    }
    private static String norm(String str){return Normalizer.normalize(str==null?"":str,Normalizer.Form.NFD).replaceAll("\\p{M}+","").toLowerCase(Locale.ROOT).trim();}
    private static int section(String s){
        String n=norm(s);
        if(n.contains("votre liste de favoris")||n.contains("your favorites list")||n.contains("your favourites list"))return 0;
        if(n.contains("offres pour vos joueurs")||n.contains("offers for your players"))return 1;
        if(n.equals("vos offres")||n.equals("your offers"))return 2;
        if(n.contains("offres en attente")||n.contains("pending offers"))return 3;
        return -1;
    }
    private static boolean validNameToken(String str){
        String n=norm(str);
        if(NON_NAMES.contains(n)||!NAME.matcher(str).matches())return false;
        for(String part:n.split("\\s+"))if(NON_NAMES.contains(part))return false;
        return true;
    }
    private static int clamp(int n,int lo,int hi){return Math.max(lo,Math.min(hi,n));}
    public static List<Transfer> parse(List<Word> raw,int width){
        if(raw==null||raw.isEmpty()||width<200)return Collections.emptyList();
        List<Word> all=new ArrayList<>();Set<String> seen=new HashSet<>();
        for(Word w:raw){
            if(w==null||w.text.isEmpty()||w.text.length()>120||w.bottom<w.top||w.right<w.left)continue;
            if(seen.add(w.text+"|"+w.left+"|"+w.top+"|"+w.right))all.add(w);
        }
        all.sort(Comparator.comparingInt((Word w)->w.top).thenComparingInt(w->w.left));
        List<Word> headings=new ArrayList<>();
        for(Word w:all)if(section(w.text)>=0)headings.add(w);
        if(headings.isEmpty())return Collections.emptyList();
        List<Transfer> results=new ArrayList<>();Set<String> unique=new HashSet<>();
        for(int h=0;h<headings.size();h++){
            Word heading=headings.get(h);
            int sec=section(heading.text);
            int stop=h+1<headings.size()?headings.get(h+1).top:Integer.MAX_VALUE;
            List<Word> area=new ArrayList<>();
            for(Word w:all)if(w.top>heading.bottom&&w.top<stop)area.add(w);
            if(area.isEmpty())continue;
            // Read actual column headers when they exist; avoid fixed-width name guesses.
            int nameX=(int)(width*.16),ageX=(int)(width*.29),offerX=(int)(width*.75),endX=(int)(width*.90);
            int bodyY=heading.bottom+32;
            for(Word w:area){
                if(w.top>heading.bottom+145)break;
                String n=norm(w.text);
                if(n.equals("nom")||n.equals("name")){nameX=w.left;bodyY=Math.max(bodyY,w.bottom+2);}
                if(n.equals("age")){ageX=w.left;bodyY=Math.max(bodyY,w.bottom+2);}
                if(n.equals("offre")||n.equals("bid")){offerX=w.left;bodyY=Math.max(bodyY,w.bottom+2);}
                if(n.equals("fin")||n.equals("end")){endX=w.left;bodyY=Math.max(bodyY,w.bottom+2);}
            }
            int nameLeft=clamp(nameX-(int)(width*.045),0,width);
            int nameRight=Math.max(nameLeft+24,clamp(ageX-(int)(width*.008),0,width));
            List<Word> nameWords=new ArrayList<>();
            for(Word w:area){
                if(w.cy()<=bodyY||w.left<nameLeft||w.left>=nameRight)continue;
                if(!validNameToken(w.text))continue;
                nameWords.add(w);
            }
            nameWords.sort(Comparator.comparingInt(Word::cy).thenComparingInt(w->w.left));
            if(nameWords.isEmpty())continue;
            int medianHeight=typicalHeight(nameWords);
            int lineGap=clamp((int)(medianHeight*1.9),28,55);
            // Distinct rows in FMP have a noticeably larger vertical gap than
            // the 2 text baselines (first and last name) within one player.
            List<NameRow> rows=new ArrayList<>();
            NameRow current=null;
            for(Word w:nameWords){
                if(current==null||w.cy()-current.lastY>lineGap||w.cy()-current.firstY>clamp(medianHeight*3,45,85)){
                    current=new NameRow();rows.add(current);
                }
                current.add(w);
            }
            // Reject overlapping/ambiguous groups and one-word OCR fragments.
            for(int i=0;i<rows.size();i++){
                NameRow row=rows.get(i);
                List<Word> tokens=row.tokens;
                tokens.sort(Comparator.comparingInt(Word::cy).thenComparingInt(w->w.left));
                StringBuilder name=new StringBuilder();
                for(Word w:tokens){if(name.length()>0)name.append(' ');name.append(w.text);}
                String player=name.toString().replaceAll("\\s+"," ").trim();
                int words=player.split("\\s+").length;
                if(words<2||words>4||player.length()>55||!validPlayer(player))continue;
                int start=row.firstY-Math.max(12,medianHeight);
                int bottom=i+1<rows.size()?(row.lastY+rows.get(i+1).firstY)/2:row.lastY+clamp(medianHeight*3,50,88);
                // At a tight row transition the next player's first-line data
                // must never be attributed to this player's deadline or offer.
                if(i+1<rows.size())bottom=Math.min(bottom,rows.get(i+1).firstY-Math.max(8,medianHeight/2));
                String offer="";
                int bestPrice=Integer.MAX_VALUE;
                List<Word> times=new ArrayList<>();
                for(Word w:area){
                    if(w.cy()<start||w.cy()>=bottom)continue;
                    if(w.left>=offerX-(int)(width*.035)&&w.left<endX+(int)(width*.014)){
                        String t=w.text.trim();
                        if(MONEY.matcher(t).matches()||norm(t).equals("n/a")){
                            int score=Math.abs(w.cy()-(row.firstY+medianHeight));
                            if(score<bestPrice){offer=t;bestPrice=score;}
                        }
                    }
                    if(w.left>=endX-(int)(width*.020)&&DURATION.matcher(norm(w.text)).matches())times.add(w);
                }
                times.sort(Comparator.comparingInt(Word::cy));
                StringBuilder deadline=new StringBuilder();
                for(Word w:times){
                    if(deadline.length()>0)deadline.append(' ');
                    deadline.append(w.text);
                    if(deadline.length()>18||deadline.toString().split(" ").length>=2)break;
                }
                String key=sec+"|"+norm(player);
                if(unique.add(key))results.add(new Transfer(sec,player,offer,deadline.toString()));
            }
        }
        return results;
    }
    private static boolean validPlayer(String player){
        for(String part:player.split("\\s+"))if(!validNameToken(part))return false;
        return true;
    }
    private static int typicalHeight(List<Word> words){
        List<Integer> heights=new ArrayList<>();
        for(Word w:words)heights.add(clamp(w.h(),8,48));
        Collections.sort(heights);
        return heights.get(heights.size()/2);
    }
}
