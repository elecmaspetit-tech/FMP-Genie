package com.fmp.widget;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/** Receives a launcher success callback only after the widget was placed. */
public final class PinResultReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if(!"com.fmp.widget.PIN_SUCCESS".equals(intent.getAction()))return;
        int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if(id==AppWidgetManager.INVALID_APPWIDGET_ID) {
            Log.w("FMPWidget", "Pin success callback without widget ID");
            return;
        }
        context.getSharedPreferences("fmp_widget_status", Context.MODE_PRIVATE)
            .edit().putLong("last_added", System.currentTimeMillis()).apply();
        FavoritesWidget.updateAll(context);
    }
}
