package com.fmp.widget;

import android.app.Activity;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.content.Context;
import android.os.Build;
import android.appwidget.AppWidgetManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

/** Native controller for an independent FMP home-screen widget. */
public final class MainActivity extends Activity {
    static final String EXTRA_SECTION="section";
    static final String EXTRA_PLAYER="player";
    static final String EXTRA_OPEN_FMP="open_fmp";
    private static final int DARK=Color.rgb(8,32,8);
    private static final int GREEN=Color.rgb(132,203,87);
    private static final int LIGHT=Color.rgb(238,248,233);
    private static final int REQUEST_CAPTURE = 9032;
    private int section=0;
    private LinearLayout root, entries;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        section=Math.max(0,Math.min(3,getIntent().getIntExtra(EXTRA_SECTION,0)));
        if(getIntent().getBooleanExtra(EXTRA_OPEN_FMP,false)){
            openFmp();finish();return;
        }
        drawScreen();
        String name=getIntent().getStringExtra(EXTRA_PLAYER);
        if(name!=null&&!name.isEmpty()) {
            new Handler(Looper.getMainLooper()).post(()-> {
                for(TransferStore.Entry e:TransferStore.all(this))
                    if(e.section==section && e.name.equalsIgnoreCase(name)) {showDetail(e);break;}
            });
        }
    }
    @Override protected void onResume(){super.onResume(); if(root!=null)drawScreen();}
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);setIntent(intent);
        if(intent.getBooleanExtra(EXTRA_OPEN_FMP,false)){openFmp();return;}
        section=Math.max(0,Math.min(3,intent.getIntExtra(EXTRA_SECTION,section)));
        drawScreen();
        String player=intent.getStringExtra(EXTRA_PLAYER);
        if(player!=null)for(TransferStore.Entry e:TransferStore.all(this))
            if(e.section==section && e.name.equalsIgnoreCase(player)){showDetail(e);break;}
    }
    private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView text(String value,int size,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD);return t;
    }
    private LinearLayout vertical() {LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal() {LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private Button button(String label,Runnable r) {
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(12);
        b.setOnClickListener(v->r.run());return b;
    }
    private void drawScreen() {
        root=vertical();root.setBackgroundColor(DARK);
        setContentView(root);
        ScrollView scroll=new ScrollView(this);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        LinearLayout page=vertical();page.setPadding(dp(15),dp(16),dp(15),dp(28));
        scroll.addView(page);
        TextView title=text("FMP  •  MES TRANSFERTS",23,LIGHT,true);
        page.addView(title);
        TextView intro=text("Widget Android indépendant • suivi de la page des offres FMP",12,GREEN,false);
        intro.setPadding(0,dp(6),0,dp(12));page.addView(intro);
        AppWidgetManager widgetManager=AppWidgetManager.getInstance(this);
        int widgetCount=widgetManager.getAppWidgetIds(new ComponentName(this,FavoritesWidget.class)).length;
        TextView widgetStatus=text(widgetCount>0?"Widgets installés sur l’accueil : "+widgetCount:
                "Aucun widget encore placé sur l’accueil",12,0xFFC2D7B9,false);
        widgetStatus.setPadding(0,0,0,dp(6));page.addView(widgetStatus);
        Button pin=button("+ Ajouter le widget à l'écran d'accueil",this::requestWidgetPin);
        page.addView(pin,new LinearLayout.LayoutParams(-1,dp(48)));
        Button manual=button("Si l’ajout échoue : comment faire ?",this::showWidgetHelp);
        page.addView(manual,new LinearLayout.LayoutParams(-1,dp(44)));
        LinearLayout bar=horizontal();page.addView(bar);
        for(int i=0;i<4;i++){
            final int n=i;
            Button tab=button(new String[]{"Favoris","Reçues","Mes offres","Attente"}[i],()->{section=n;drawScreen();});
            tab.setPadding(dp(3),0,dp(3),0);
            tab.setTextColor(i==section?DARK:LIGHT);
            tab.setBackgroundTintList(ColorStateList.valueOf(i==section?GREEN:0xFF31552B));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1);
            p.setMargins(dp(2),0,dp(2),0);bar.addView(tab,p);
        }
        long last=TransferStore.lastCapture(this);
        String lastText=last==0?"Aucune lecture FMP enregistrée":
            "Dernière lecture : "+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(last));
        TextView status=text(lastText,12,0xFFBDD6AF,false);
        status.setPadding(0,dp(12),0,dp(9));page.addView(status);
        Button startCapture=button("Démarrer lecture FMP en direct",this::startCaptureSession);
        page.addView(startCapture,new LinearLayout.LayoutParams(-1,dp(52)));
        Button stopCapture=button("Arrêter le partage d'écran",this::stopCaptureSession);
        page.addView(stopCapture,new LinearLayout.LayoutParams(-1,dp(48)));
        Button clean=button("Effacer les anciennes lectures OCR erronées",this::confirmClearCaptured);
        page.addView(clean,new LinearLayout.LayoutParams(-1,dp(48)));
        Button open=button("Ouvrir FMP",this::openFmp);
        page.addView(open,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView note=text("1. Effacez les lectures incorrectes des anciennes versions. 2. Appuyez sur « Démarrer lecture » et autorisez le partage de l'application FMP dans la fenêtre Android. 3. Dans FMP, affichez « Offres concernant votre équipe » et faites défiler lentement vos favoris. 4. Le widget conserve les dernières offres reconnues, sans enchère automatique. Les montants et délais OCR restent à confirmer dans FMP.",12,0xFFD1DCC8,false);
        note.setPadding(0,dp(13),0,dp(18));page.addView(note);
        LinearLayout listTitle=horizontal();page.addView(listTitle);
        TextView label=text(VisibleTransfersParser.SECTIONS[section],20,LIGHT,true);
        listTitle.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        Button add=button("+ Ajouter",()->showEdit(null));
        listTitle.addView(add);
        entries=vertical();entries.setPadding(0,dp(6),0,0);page.addView(entries);
        List<TransferStore.Entry> all=TransferStore.all(this);
        int count=0;
        for(TransferStore.Entry entry:all)if(entry.section==section){addEntry(entry);count++;}
        if(count==0){
            TextView empty=text("Aucun joueur enregistré dans cette catégorie.\nAppuyez sur « + Ajouter » pour suivre un joueur manuellement.",14,0xFFC8DCC1,false);
            empty.setPadding(dp(10),dp(22),dp(10),dp(20));entries.addView(empty);
        }
        TextView privacy=text("Confidentialité : capture volontaire par Android et analyse OCR sur le téléphone. Aucune capture enregistrée ni transmise. Seuls les noms, montants et délais reconnus sur la page d'offres FMP sont conservés. Arrêtez le partage après la consultation. Pas d'achats automatiques.",12,0xFF9EB394,false);
        privacy.setPadding(dp(4),dp(13),dp(4),dp(6));page.addView(privacy);
    }
    private void addEntry(TransferStore.Entry e) {
        LinearLayout card=vertical();card.setPadding(dp(12),dp(12),dp(12),dp(10));card.setBackgroundColor(0xFF17420E);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(9);entries.addView(card,cp);
        TextView name=text(e.name,17,LIGHT,true);card.addView(name);
        String offer=e.offer.isEmpty()?"Offre non relevée":"Offre : "+e.offer;
        String deadline=e.deadline.isEmpty()?"":"  •  Fin : "+e.deadline;
        TextView details=text(offer+deadline,13,GREEN,false);details.setPadding(0,dp(5),0,dp(5));card.addView(details);
        String stamp=e.updated==0?"Ajout manuel":DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(e.updated));
        card.addView(text("Source : "+e.source+" · "+stamp,11,0xFFBFD3B6,false));
        if(!e.draft.isEmpty())card.addView(text("Brouillon d'enchère : "+e.draft,12,0xFFFBE4A5,true));
        LinearLayout controls=horizontal();card.addView(controls);
        controls.addView(button("Détails",()->showDetail(e)),new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("Modifier",()->showEdit(e)),new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("FMP ↗",this::openFmp),new LinearLayout.LayoutParams(0,dp(42),1));
    }
    private void showDetail(TransferStore.Entry e) {
        String message="Catégorie : "+VisibleTransfersParser.SECTIONS[e.section]+"\n"
            +"Offre affichée : "+(e.offer.isEmpty()?"non connue":e.offer)+"\n"
            +"Fin : "+(e.deadline.isEmpty()?"non connue":e.deadline)+"\n"
            +"Brouillon : "+(e.draft.isEmpty()?"aucun":e.draft)+"\n\n"
            +"Le widget ne réalise pas d'enchère. Toute opération réelle doit être confirmée dans FMP.";
        new AlertDialog.Builder(this).setTitle(e.name).setMessage(message)
            .setPositiveButton("Ouvrir FMP",(d,w)->openFmp())
            .setNeutralButton("Préparer une offre",(d,w)->showDraft(e))
            .setNegativeButton("Fermer",null).show();
    }
    private void showDraft(TransferStore.Entry e) {
        EditText field=new EditText(this);field.setSingleLine();field.setHint("Montant à saisir ensuite dans FMP");
        field.setInputType(InputType.TYPE_CLASS_NUMBER);field.setText(e.draft);
        new AlertDialog.Builder(this).setTitle("Brouillon pour "+e.name).setView(field)
            .setPositiveButton("Conserver le brouillon",(d,w)->{
                String number=field.getText().toString().trim();
                if(number.length()>18){Toast.makeText(this,"Montant trop long",Toast.LENGTH_SHORT).show();return;}
                e.draft=number;TransferStore.upsert(this,e);drawScreen();
            }).setNegativeButton("Annuler",null).show();
    }
    private EditText input(String hint,String initial) {
        EditText e=new EditText(this);e.setSingleLine();e.setText(initial);
        e.setHint(hint);e.setTextSize(15);return e;
    }
    private void showEdit(TransferStore.Entry existing) {
        LinearLayout form=vertical();form.setPadding(dp(18),dp(8),dp(18),0);
        EditText name=input("Nom du joueur",existing==null?"":existing.name);
        EditText bid=input("Offre affichée",existing==null?"":existing.offer);
        EditText deadline=input("Fin d'enchère (texte)",existing==null?"":existing.deadline);
        form.addView(name);form.addView(bid);form.addView(deadline);
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(existing==null?"Ajouter un joueur":"Modifier un joueur")
            .setView(form).setPositiveButton("Enregistrer",(d,w)->{
                String n=name.getText().toString().trim();
                if(n.isEmpty()||n.length()>65){Toast.makeText(this,"Nom invalide",Toast.LENGTH_SHORT).show();return;}
                if(existing!=null&&!existing.name.equalsIgnoreCase(n))TransferStore.remove(this,existing.section,existing.name);
                TransferStore.upsert(this,new TransferStore.Entry(section,n,
                    bid.getText().toString().trim(),deadline.getText().toString().trim(),
                    existing==null?"":existing.draft,System.currentTimeMillis(),"manuel"));
                drawScreen();
            }).setNegativeButton("Annuler",null);
        if(existing!=null)b.setNeutralButton("Supprimer",(d,w)->new AlertDialog.Builder(this)
            .setTitle("Supprimer "+existing.name+" ?")
            .setPositiveButton("Supprimer",(d2,w2)->{TransferStore.remove(this,existing.section,existing.name);drawScreen();})
            .setNegativeButton("Annuler",null).show());
        b.show();
    }

    private void startCaptureSession() {
        try {
            MediaProjectionManager manager=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            if(manager==null) {Toast.makeText(this,"Partage d'écran indisponible",Toast.LENGTH_LONG).show();return;}
            Intent request = Build.VERSION.SDK_INT>=34
                ? manager.createScreenCaptureIntent(MediaProjectionConfig.createConfigForUserChoice())
                : manager.createScreenCaptureIntent();
            startActivityForResult(request, REQUEST_CAPTURE);
        } catch(Exception e) {
            Toast.makeText(this,"Partage indisponible : "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQUEST_CAPTURE)return;
        if(resultCode!=RESULT_OK||data==null){
            Toast.makeText(this,"Partage non autorisé",Toast.LENGTH_SHORT).show();return;
        }
        Intent service=new Intent(this,FmpProjectionService.class);
        service.setAction(FmpProjectionService.ACTION_START);
        service.putExtra(FmpProjectionService.EXTRA_RESULT_CODE,resultCode);
        service.putExtra(FmpProjectionService.EXTRA_RESULT_DATA,data);
        try {
            startForegroundService(service);
            Toast.makeText(this,"Lecture activée. Ouvrez la page des offres dans FMP.",Toast.LENGTH_LONG).show();
        } catch(Exception e){Toast.makeText(this,"Impossible de lancer la lecture : "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();}
    }
    private void stopCaptureSession() {
        Intent service=new Intent(this,FmpProjectionService.class).setAction(FmpProjectionService.ACTION_STOP);
        startService(service);
        Toast.makeText(this,"Arrêt demandé",Toast.LENGTH_SHORT).show();
    }

    private void confirmClearCaptured() {
        new AlertDialog.Builder(this)
            .setTitle("Effacer les lectures OCR ?")
            .setMessage("Retire les joueurs importés par la lecture d'écran, y compris les noms mélangés. Vos fiches saisies manuellement restent enregistrées. La prochaine capture FMP remplira à nouveau le widget.")
            .setNegativeButton("Annuler",null)
            .setPositiveButton("Effacer",(d,w)->{
                int count=TransferStore.clearCaptured(this);
                Toast.makeText(this,count+" fiche(s) OCR effacée(s)",Toast.LENGTH_SHORT).show();
                drawScreen();
            }).show();
    }
    private void requestWidgetPin() {
        try {
            AppWidgetManager widgets=AppWidgetManager.getInstance(this);
            if(!widgets.isRequestPinAppWidgetSupported()) {
                showWidgetHelp();return;
            }
            Intent response=new Intent(this,PinResultReceiver.class)
                .setAction("com.fmp.widget.PIN_SUCCESS");
            PendingIntent success=PendingIntent.getBroadcast(this,2001,response,
                PendingIntent.FLAG_MUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
            boolean accepted=widgets.requestPinAppWidget(
                new ComponentName(this,FavoritesWidget.class),null,success);
            if(!accepted)showWidgetHelp();
            // The launcher owns the confirmation. No success claim until the callback fires.
        }catch(RuntimeException ex){
            android.util.Log.e("FMPWidget", "Unable to request widget pin", ex);
            showWidgetHelp();
        }
    }
    private void showWidgetHelp() {
        new AlertDialog.Builder(this)
            .setTitle("Ajouter le widget sur Samsung")
            .setMessage("1. Revenez à l’écran d’accueil.\n"
                +"2. Maintenez un doigt sur une zone vide.\n"
                +"3. Choisissez Widgets.\n"
                +"4. Cherchez FMP Mes transferts.\n"
                +"5. Sélectionnez le widget 4 × 2, puis Ajouter.\n\n"
                +"Libérez une zone 4 × 2 ou essayez une autre page d’accueil. "
                +"Si le widget refuse encore de s’ajouter, faites une capture de l’erreur.")
            .setPositiveButton("Compris",null).show();
    }
    private void openFmp() {
        try {
            Intent launch=getPackageManager().getLaunchIntentForPackage("com.ledev.fmp.mobile");
            if(launch==null){
                new AlertDialog.Builder(this).setTitle("FMP non détecté")
                    .setMessage("Installez ou ouvrez l'APK officiel FMP. Aucun lien profond vers la page des favoris n'a été vérifié.")
                    .setPositiveButton("Fermer",null).show();return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        }catch(Exception e){Toast.makeText(this,"Impossible d'ouvrir FMP sur cet appareil",Toast.LENGTH_LONG).show();}
    }
}
