package com.fmp.widget;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Private local cache only; never logs in, never accesses a game server. */
public final class TransferStore {
    private static final String PREF="fmp_widget_private";
    public static final class Entry {
        public int section;
        public String name, offer, deadline, draft;
        public long updated;
        public String source;
        public Entry(int section,String name,String offer,String deadline,String draft,long updated,String source) {
            this.section=section;this.name=name;this.offer=offer;this.deadline=deadline;
            this.draft=draft;this.updated=updated;this.source=source;
        }
    }
    private static SharedPreferences prefs(Context ctx) {
        return ctx.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
    }
    public static synchronized List<Entry> all(Context ctx) {
        List<Entry> rows=new ArrayList<>();
        try {
            JSONArray j=new JSONArray(prefs(ctx).getString("rows","[]"));
            for(int i=0;i<j.length();i++) {
                JSONObject o=j.getJSONObject(i);
                int section=o.optInt("section",0);
                String name=o.optString("name","").trim();
                if(section<0 || section>3 || name.isEmpty())continue;
                rows.add(new Entry(section,name,o.optString("offer",""),o.optString("deadline",""),
                    o.optString("draft",""),o.optLong("updated",0),o.optString("source","manual")));
            }
        }catch(Exception ignored) { /* leave corrupt or partial data hidden; no crash */ }
        rows.sort(Comparator.comparingInt((Entry e)->e.section).thenComparing(e->e.name,String.CASE_INSENSITIVE_ORDER));
        return rows;
    }
    public static synchronized void save(Context ctx,List<Entry> entries) {
        JSONArray a=new JSONArray();
        for (Entry e:entries) {
            JSONObject o=new JSONObject();
            try {
                o.put("section",e.section);o.put("name",e.name);o.put("offer",e.offer);
                o.put("deadline",e.deadline);o.put("draft",e.draft);
                o.put("updated",e.updated);o.put("source",e.source);
                a.put(o);
            }catch(Exception ignored) { }
        }
        prefs(ctx).edit().putString("rows",a.toString()).apply();
        FavoritesWidget.updateAll(ctx);
    }
    public static synchronized void upsert(Context ctx,Entry e) {
        List<Entry> rows=all(ctx);
        for (int i=0;i<rows.size();i++) {
            Entry old=rows.get(i);
            if(old.section==e.section && old.name.equalsIgnoreCase(e.name)) {
                if(e.draft.isEmpty())e.draft=old.draft;
                rows.set(i,e);save(ctx,rows);return;
            }
        }
        rows.add(e);save(ctx,rows);
    }
    public static synchronized void remove(Context ctx,int section,String name) {
        List<Entry> rows=all(ctx);
        rows.removeIf(e->e.section==section && e.name.equalsIgnoreCase(name));
        save(ctx,rows);
    }
    public static synchronized void mergeCapture(Context ctx,List<VisibleTransfersParser.Transfer> captured) {
        List<Entry> rows=all(ctx);
        long now=System.currentTimeMillis();
        for(VisibleTransfersParser.Transfer r:captured) {
            // Partial scroll capture: never remove favorites not currently visible.
            boolean updated=false;
            for(int i=0;i<rows.size();i++) {
                Entry old=rows.get(i);
                if(old.section==r.section && old.name.equalsIgnoreCase(r.name)) {
                    rows.set(i,new Entry(r.section,r.name,r.offer,r.deadline,old.draft,now,"FMP écran"));
                    updated=true;break;
                }
            }
            if(!updated)rows.add(new Entry(r.section,r.name,r.offer,r.deadline,"",now,"FMP écran"));
        }
        prefs(ctx).edit().putLong("last_capture",now).apply();
        save(ctx,rows);
    }
    /** Removes only OCR-derived entries; preserves user-entered favorites/drafts. */
    public static synchronized int clearCaptured(Context ctx) {
        List<Entry> rows=all(ctx);
        int before=rows.size();
        rows.removeIf(e -> "FMP écran".equals(e.source));
        prefs(ctx).edit().remove("last_capture").apply();
        save(ctx,rows);
        return before-rows.size();
    }
    public static long lastCapture(Context ctx) { return prefs(ctx).getLong("last_capture",0); }
    public static void storeDiagnostic(Context ctx,String snapshot) {
        // Only FMP transfer pages; private app storage, capped; never transmitted.
        prefs(ctx).edit().putString("diagnostic",snapshot.length()>7500?snapshot.substring(0,7500):snapshot).apply();
    }
    public static String diagnostic(Context ctx){return prefs(ctx).getString("diagnostic","Aucune capture de l'écran des transferts FMP.");}
}
