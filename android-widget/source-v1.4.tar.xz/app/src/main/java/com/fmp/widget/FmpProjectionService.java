package com.fmp.widget;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import android.content.res.Resources;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** Opt-in screen sharing: on-device OCR, retains text of visible FMP offers only. */
public final class FmpProjectionService extends Service {
    public static final String ACTION_START="com.fmp.widget.START_READING";
    public static final String ACTION_STOP="com.fmp.widget.STOP_READING";
    public static final String EXTRA_RESULT_CODE="result_code";
    public static final String EXTRA_RESULT_DATA="result_data";
    private static final String CHANNEL="fmp_live_capture";
    private static final int NOTIFICATION_ID=4237;
    private static final long MIN_OCR_INTERVAL_MS=3500L;
    private final AtomicBoolean busy=new AtomicBoolean(false);
    private final Handler mainHandler=new Handler(Looper.getMainLooper());
    private HandlerThread thread;
    private Handler imageHandler;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private ImageReader reader;
    private TextRecognizer recognizer;
    private long lastScan;
    private boolean stopping;
    private int frameWidth, frameHeight;

    @Override public IBinder onBind(Intent intent){return null;}
    @Override public void onCreate(){
        super.onCreate();
        NotificationManager n=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        n.createNotificationChannel(new NotificationChannel(CHANNEL,"Lecture FMP à la demande",NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent command,int flags,int startId){
        if(command==null)return START_NOT_STICKY;
        if(ACTION_STOP.equals(command.getAction())){stopSelf();return START_NOT_STICKY;}
        if(!ACTION_START.equals(command.getAction()))return START_NOT_STICKY;
        if(projection!=null)return START_NOT_STICKY;
        try {
            Intent stop=new Intent(this,FmpProjectionService.class).setAction(ACTION_STOP);
            PendingIntent stopPi=PendingIntent.getService(this,10,stop,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
            Notification notification=new Notification.Builder(this,CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("FMP • Lecture volontaire des offres")
                .setContentText("Ouvrez les offres FMP. Arrêtez la capture après consultation.")
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null,"Arrêter",stopPi).build())
                .build();
            if(Build.VERSION.SDK_INT>=29) startForeground(NOTIFICATION_ID,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            else startForeground(NOTIFICATION_ID,notification);
            int code=command.getIntExtra(EXTRA_RESULT_CODE,0);
            Intent data=Build.VERSION.SDK_INT>=33
                ? command.getParcelableExtra(EXTRA_RESULT_DATA,Intent.class)
                : (Intent)command.getParcelableExtra(EXTRA_RESULT_DATA);
            if(data==null||code==0){stopSelf();return START_NOT_STICKY;}
            MediaProjectionManager manager=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection=manager.getMediaProjection(code,data);
            if(projection==null){stopSelf();return START_NOT_STICKY;}
            projection.registerCallback(new MediaProjection.Callback(){
                @Override public void onStop(){stopSelf();}
                @Override public void onCapturedContentResize(int w,int h){
                    // Android may resize captured app content. Restarting the capture requires
                    // a new media projection grant on Android 14+, so avoid recreating display.
                }
            },mainHandler);
            DisplayMetrics dm=Resources.getSystem().getDisplayMetrics();
            int width=dm.widthPixels, height=dm.heightPixels;
            WindowManager wm=(WindowManager)getSystemService(Context.WINDOW_SERVICE);
            if(Build.VERSION.SDK_INT>=30){
                Rect r=wm.getMaximumWindowMetrics().getBounds();
                width=r.width();height=r.height();
            }
            frameWidth=Math.max(300,width);frameHeight=Math.max(400,height);
            thread=new HandlerThread("fmp-ocr-capture");thread.start();imageHandler=new Handler(thread.getLooper());
            recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
            reader=ImageReader.newInstance(frameWidth,frameHeight,PixelFormat.RGBA_8888,2);
            reader.setOnImageAvailableListener(this::onFrame,imageHandler);
            virtualDisplay=projection.createVirtualDisplay("FMP transfert OCR",frameWidth,frameHeight,
                dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,imageHandler);
        } catch(Exception e){
            android.util.Log.e("FMPProjection","Cannot start screen capture",e);
            stopSelf();
        }
        return START_NOT_STICKY;
    }
    private void onFrame(ImageReader source){
        Image frame=null;
        try {
            frame=source.acquireLatestImage();
            if(frame==null)return;
            long now=android.os.SystemClock.elapsedRealtime();
            if(now-lastScan<MIN_OCR_INTERVAL_MS||!busy.compareAndSet(false,true))return;
            lastScan=now;
            Image.Plane plane=frame.getPlanes()[0];
            ByteBuffer pixels=plane.getBuffer();
            int stride=plane.getRowStride(),pixelStride=plane.getPixelStride();
            if(pixelStride!=4){busy.set(false);return;}
            int expandedWidth=frame.getWidth()+(stride-pixelStride*frame.getWidth())/pixelStride;
            Bitmap expanded=Bitmap.createBitmap(expandedWidth,frame.getHeight(),Bitmap.Config.ARGB_8888);
            expanded.copyPixelsFromBuffer(pixels);
            Bitmap screenshot=Bitmap.createBitmap(expanded,0,0,frame.getWidth(),frame.getHeight());
            expanded.recycle();
            int capturedWidth=frame.getWidth();
            recognizer.process(InputImage.fromBitmap(screenshot,0))
                .addOnSuccessListener(text->handleRecognized(text,capturedWidth))
                .addOnFailureListener(err->android.util.Log.w("FMPProjection","Local OCR failed",err))
                .addOnCompleteListener(done->{screenshot.recycle();busy.set(false);});
        } catch(Exception e){
            busy.set(false);
            android.util.Log.w("FMPProjection","Ignored capture frame",e);
        } finally {if(frame!=null)frame.close();}
    }
    private static boolean isOfferHeading(String text){
        String s=java.text.Normalizer.normalize(text==null?"":text,java.text.Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT);
        return s.contains("votre liste de favoris")||s.contains("offres pour vos joueurs")
            ||s.contains("offres en attente")||s.equals("vos offres")
            ||s.contains("your favorites list")||s.contains("your favourites list")
            ||s.contains("offers for your players")||s.equals("your offers")||s.contains("pending offers");
    }
    private void handleRecognized(Text response,int displayWidth){
        if(stopping||response==null)return;
        List<VisibleTransfersParser.Word> words=new ArrayList<>();
        boolean offerPage=false;
        for(Text.TextBlock block:response.getTextBlocks()){
            for(Text.Line line:block.getLines()){
                if(isOfferHeading(line.getText())){
                    offerPage=true;
                    Rect b=line.getBoundingBox();
                    if(b!=null)words.add(new VisibleTransfersParser.Word(line.getText(),b.left,b.top,b.right,b.bottom));
                }else{
                    for(Text.Element elem:line.getElements()){
                        Rect b=elem.getBoundingBox();
                        if(b!=null) words.add(new VisibleTransfersParser.Word(elem.getText(),b.left,b.top,b.right,b.bottom));
                    }
                }
            }
        }
        // Do not persist anything from unrelated screens or sensitive dialogs.
        if(!offerPage)return;
        List<VisibleTransfersParser.Transfer> transfers=VisibleTransfersParser.parse(words,displayWidth);
        if(!transfers.isEmpty()) TransferStore.mergeCapture(getApplicationContext(),transfers);
    }
    @Override public void onDestroy(){
        stopping=true;
        if(reader!=null){reader.setOnImageAvailableListener(null,null);reader.close();reader=null;}
        if(virtualDisplay!=null){virtualDisplay.release();virtualDisplay=null;}
        if(projection!=null){MediaProjection p=projection;projection=null;p.stop();}
        if(recognizer!=null){recognizer.close();recognizer=null;}
        if(thread!=null){thread.quitSafely();thread=null;}
        super.onDestroy();
    }
}
