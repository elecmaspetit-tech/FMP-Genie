#!/usr/bin/env python3
from pathlib import Path
import re, xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
resources = list((root/'app/src/main/res').rglob('*.xml'))
for p in [root/'app/src/main/AndroidManifest.xml']+resources:
    ET.parse(p)
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
assert 'android.permission.INTERNET' not in manifest
assert 'QUERY_ALL_PACKAGES' not in manifest
assert 'BIND_ACCESSIBILITY_SERVICE' not in manifest
assert 'com.ledev.fmp.mobile' in manifest
xml=(root/'app/src/main/res/layout/fmp_widget.xml').read_text()
ids=set(re.findall(r'@\+id/(\w+)',xml))
provider=(root/'app/src/main/java/com/fmp/widget/FavoritesWidget.java').read_text()
used=set(re.findall(r'R\.id\.(\w+)',provider))
assert used.issubset(ids),f'Widget view IDs missing: {used-ids}'
for c in ('MainActivity','FavoritesWidget','VisibleTransfersParser','TransferStore'):
    assert (root/'app/src/main/java/com/fmp/widget'/f'{c}.java').exists()
assert 'BIND_ACCESSIBILITY_SERVICE' not in manifest and 'android.permission.INTERNET' not in manifest
assert 'FOREGROUND_SERVICE_MEDIA_PROJECTION' in manifest and 'mediaProjection' in manifest
print(f'OK : {len(resources)+1} fichiers XML analysés, {len(used)} IDs widget, manifeste sans permission INTERNET, sources présentes')

assert (root/'app/src/main/res/drawable-nodpi/fmp_widget_preview.png').exists()
assert 'android:previewImage' in (root/'app/src/main/res/xml/fmp_widget_info.xml').read_text()
assert (root/'app/src/main/java/com/fmp/widget/PinResultReceiver.java').exists()
assert 'android:exported="false"' in manifest

assert (root/"app/src/main/java/com/fmp/widget/FmpProjectionService.java").exists()
