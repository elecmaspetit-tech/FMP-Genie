import com.fmp.widget.VisibleTransfersParser;
import java.util.ArrayList;
import java.util.List;

/** No Android SDK required; regression suite for real FMP mobile table OCR. */
public final class ParserTest {
    private static void add(List<VisibleTransfersParser.Word> a,String t,int x,int y){
        a.add(new VisibleTransfersParser.Word(t,x,y,x+Math.max(18,t.length()*8),y+22));
    }
    private static void eq(Object want,Object got){
        if(!want.equals(got))throw new AssertionError("Expected "+want+" got "+got);
    }
    private static VisibleTransfersParser.Transfer find(List<VisibleTransfersParser.Transfer> rs,String name){
        for(VisibleTransfersParser.Transfer t:rs)if(t.name.equals(name))return t;
        throw new AssertionError("Missing "+name+" from "+rs);
    }
    private static void legacySanity(){
        List<VisibleTransfersParser.Word> w=new ArrayList<>();
        add(w,"Offres pour vos joueurs",11,115);
        add(w,"Nom",117,161);add(w,"Age",205,161);add(w,"Offre",542,161);add(w,"Fin",638,161);
        add(w,"Adrian",88,216);add(w,"Joseph",88,244);add(w,"38",210,225);
        add(w,"495,289",546,245);add(w,"2j",644,212);
        add(w,"Vos Offres",10,335);
        add(w,"Nom",117,370);add(w,"Age",205,370);add(w,"Offre",540,370);
        add(w,"John",89,425);add(w,"Dionysiou",89,455);add(w,"35",209,434);
        add(w,"790,372",547,458);add(w,"Vendu",646,438);
        add(w,"Offres en attente",11,535);
        add(w,"Votre liste de favoris",10,612);
        add(w,"Nom",116,654);add(w,"Age",205,654);add(w,"Offre",539,654);add(w,"Fin",645,654);
        add(w,"Axel",90,702);add(w,"Focquet",90,740);add(w,"34",210,714);
        add(w,"2,491,547",544,740);add(w,"14h",646,704);
        add(w,"Hichem",89,818);add(w,"Becker",89,853);add(w,"37",212,832);
        add(w,"2,830,533",541,856);add(w,"1j",650,820);
        List<VisibleTransfersParser.Transfer> r=VisibleTransfersParser.parse(w,709);
        eq(4,r.size());eq("Adrian Joseph",r.get(0).name);eq("495,289",r.get(0).offer);
        eq(1,r.get(0).section);eq(2,find(r,"John Dionysiou").section);
        eq("2,491,547",find(r,"Axel Focquet").offer);
        eq("2,830,533",find(r,"Hichem Becker").offer);
    }
    private static void screenshotRegression(){
        List<VisibleTransfersParser.Word> w=new ArrayList<>();
        add(w,"Votre liste de favoris",10,600);
        add(w,"Info",26,643); add(w,"Nom",117,643);add(w,"Age",205,643);
        add(w,"Offre",540,643);add(w,"Fin",641,643);
        // Real-world screenshot: age+position OCR garbage must never become a name.
        add(w,"Axel",123,703);add(w,"Focquet",120,738);add(w,"34",210,709);
        add(w,"2,491,547",546,739);add(w,"14h",645,704);add(w,"01m",647,739);
        add(w,"Hichem",123,812);add(w,"Becker",121,847);add(w,"3711DG¡G",208,815);
        add(w,"2,830,533",545,851);add(w,"1j",647,814);add(w,"13h",645,846);
        add(w,"Jorge",120,926);add(w,"Gonçalves",118,957);add(w,"43",209,930);
        add(w,"N/A",546,960);
        add(w,"Lamine",122,1035);add(w,"Scanella",119,1068);add(w,"38",209,1036);
        add(w,"N/A",546,1067);
        List<VisibleTransfersParser.Transfer> r=VisibleTransfersParser.parse(w,709);
        eq(4,r.size());
        eq("14h 01m",find(r,"Axel Focquet").deadline);
        eq("2,491,547",find(r,"Axel Focquet").offer);
        eq("1j 13h",find(r,"Hichem Becker").deadline);
        eq("2,830,533",find(r,"Hichem Becker").offer);
        eq("N/A",find(r,"Jorge Gonçalves").offer);
        eq("N/A",find(r,"Lamine Scanella").offer);
        for(VisibleTransfersParser.Transfer t:r){
            if(t.name.contains("3711")||t.name.contains("Becker Jorge")||t.name.contains("Focquet Hichem"))
                throw new AssertionError("Corrupted player: "+t);
        }
    }
    private static void missingAgesAndUnrelatedScreen(){
        List<VisibleTransfersParser.Word> w=new ArrayList<>();
        add(w,"Votre liste de favoris",10,100);
        add(w,"Nom",110,144);add(w,"Age",208,144);add(w,"Offre",543,144);add(w,"Fin",639,144);
        add(w,"Karim",122,201);add(w,"Sebastiao",119,234);add(w,"N/A",543,233);
        add(w,"Florent",122,321);add(w,"Souchard",118,352);add(w,"N/A",541,355);
        List<VisibleTransfersParser.Transfer> r=VisibleTransfersParser.parse(w,709);
        eq(2,r.size());eq("N/A",find(r,"Karim Sebastiao").offer);
        find(r,"Florent Souchard");
        List<VisibleTransfersParser.Word> bad=new ArrayList<>();
        add(bad,"Équipe / tactiques",3,10);add(bad,"Axel",117,110);add(bad,"Focquet",117,140);
        eq(0,VisibleTransfersParser.parse(bad,709).size());
        eq(0,VisibleTransfersParser.parse(null,709).size());
    }
    public static void main(String[] args){
        legacySanity(); screenshotRegression(); missingAgesAndUnrelatedScreen();
        System.out.println("OK: FMP multi-section OCR regression, adjacent names, bids/deadlines, malformed ages, missing ages, unrelated screens");
    }
}
