#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p /tmp/fmp_widget_test_classes
javac -encoding UTF-8 -d /tmp/fmp_widget_test_classes \
  app/src/main/java/com/fmp/widget/VisibleTransfersParser.java tests/ParserTest.java
java -cp /tmp/fmp_widget_test_classes ParserTest
