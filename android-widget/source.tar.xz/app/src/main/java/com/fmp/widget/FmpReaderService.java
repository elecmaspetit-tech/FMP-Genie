package com.fmp.widget;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Rect;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Optional Android accessibility reader: scans only the official FMP application,
 * on the transfer screen, while it is actually visible. Does NOT perform clicks,
 * submit bids, record credentials, access the network or run background scraping.
 */
public final class FmpReaderService extends AccessibilityService {
    private static final String TARGET="com.ledev.fmp.mobile";
    private long lastRead=0;
    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if(event==null || event.getPackageName()==null || !TARGET.contentEquals(event.getPackageName()))return;
        long now=SystemClock.elapsedRealtime();
        if(now-lastRead<1800)return;
        lastRead=now;
        AccessibilityNodeInfo root=getRootInActiveWindow();
        if(root==null || root.getPackageName()==null || !TARGET.contentEquals(root.getPackageName()))return;
        try {
            List<VisibleTransfersParser.Word> words=new ArrayList<>();
            collect(root,words,new HashSet<>(),0);
            boolean isTransfers=false;
            for(VisibleTransfersParser.Word w:words) {
                String s=w.text.toLowerCase(java.util.Locale.ROOT);
                if(s.contains("liste de favoris")||s.contains("favorites list")||s.contains("favourites list")
                    ||s.contains("offres pour vos joueurs")||s.contains("offers for your players")
                    ||s.equals("vos offres")||s.contains("offres en attente")||s.equals("your offers")) {
                    isTransfers=true;break;
                }
            }
            if(!isTransfers)return;
            StringBuilder debug=new StringBuilder("Textes d'accessibilité FMP (lecture locale) :\n");
            for(VisibleTransfersParser.Word w:words) if(debug.length()<7200)
                debug.append(w.top).append(',').append(w.left).append(": ").append(w.text).append('\n');
            List<VisibleTransfersParser.Transfer> offers=VisibleTransfersParser.parse(words,getResources().getDisplayMetrics().widthPixels);
            debug.append("\nLignes reconnues : ").append(offers.size());
            TransferStore.storeDiagnostic(this,debug.toString());
            if(!offers.isEmpty())TransferStore.mergeCapture(this,offers);
        }catch(RuntimeException ignored){/* WebView may update while reading; try next time */}
        finally { root.recycle(); }
    }
    private void collect(AccessibilityNodeInfo node,List<VisibleTransfersParser.Word> out,Set<String> seen,int depth) {
        if(node==null || depth>28 || out.size()>650)return;
        CharSequence t=node.getText();
        if(t==null || t.length()==0)t=node.getContentDescription();
        if(t!=null && t.length()>0) {
            Rect r=new Rect();node.getBoundsInScreen(r);
            String v=t.toString().trim();
            String key=v+"@"+r.left+":"+r.top;
            if(v.length()<=160 && seen.add(key))out.add(new VisibleTransfersParser.Word(v,r.left,r.top,r.right,r.bottom));
        }
        for(int i=0;i<node.getChildCount() && out.size()<650;i++) {
            AccessibilityNodeInfo child=node.getChild(i);
            if(child!=null) {
                try {collect(child,out,seen,depth+1);} finally {child.recycle();}
            }
        }
    }
    @Override public void onInterrupt() { }
}
