package com.fmp.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.widget.RemoteViews;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/** Interactive home-screen widget. Browsing and notes are local; purchase requires FMP. */
public final class FavoritesWidget extends AppWidgetProvider {
    private static final String NEXT="com.fmp.widget.PAGE_NEXT";
    private static final String PREV="com.fmp.widget.PAGE_PREV";
    private static final String TAB="com.fmp.widget.TAB";
    private static final String STATE="widget_tabs";

    public static void updateAll(Context context) {
        AppWidgetManager m=AppWidgetManager.getInstance(context);
        int[] ids=m.getAppWidgetIds(new ComponentName(context,FavoritesWidget.class));
        for (int id:ids) render(context,m,id);
    }
    @Override public void onUpdate(Context context,AppWidgetManager m,int[] ids) {
        for (int id:ids) render(context,m,id);
    }
    @Override public void onDeleted(Context context,int[] ids) {
        for (int id:ids) context.getSharedPreferences(STATE,Context.MODE_PRIVATE).edit()
            .remove("tab_"+id).remove("page_"+id).apply();
    }
    @Override public void onReceive(Context context,Intent intent) {
        String action=intent.getAction();
        if (NEXT.equals(action)||PREV.equals(action)||TAB.equals(action)) {
            int id=intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,-1);
            if(id>=0) {
                int section=context.getSharedPreferences(STATE,Context.MODE_PRIVATE).getInt("tab_"+id,0);
                int page=context.getSharedPreferences(STATE,Context.MODE_PRIVATE).getInt("page_"+id,0);
                if(TAB.equals(action)) { section=(section+1)%4;page=0; }
                else {
                    int count=0;
                    for(TransferStore.Entry entry:TransferStore.all(context))if(entry.section==section)count++;
                    int pages=Math.max(1,(count+1)/2);
                    page=(page+(NEXT.equals(action)?1:pages-1))%pages;
                }
                context.getSharedPreferences(STATE,Context.MODE_PRIVATE).edit()
                    .putInt("tab_"+id,section).putInt("page_"+id,page).apply();
                render(context,AppWidgetManager.getInstance(context),id);
            }
            return;
        }
        super.onReceive(context,intent);
    }
    private static PendingIntent tabClick(Context ctx,int widgetId,String action,int offset) {
        Intent i=new Intent(ctx,FavoritesWidget.class).setAction(action);
        i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID,widgetId);
        i.setData(Uri.parse("fmpwidget://tab/"+widgetId+"/"+offset));
        return PendingIntent.getBroadcast(ctx,widgetId*10+offset,i,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
    }
    private static PendingIntent activityClick(Context ctx,int widgetId,int section,String name,int index) {
        Intent i=new Intent(ctx,MainActivity.class);
        i.putExtra(MainActivity.EXTRA_SECTION,section);
        if(name!=null)i.putExtra(MainActivity.EXTRA_PLAYER,name);
        i.setData(Uri.parse("fmpwidget://view/"+widgetId+"/"+index+"/"+section));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(ctx,widgetId*100+index,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    private static void render(Context ctx,AppWidgetManager mgr,int widgetId) {
        int section=ctx.getSharedPreferences(STATE,Context.MODE_PRIVATE).getInt("tab_"+widgetId,0);
        RemoteViews rv=new RemoteViews(ctx.getPackageName(),R.layout.fmp_widget);
        rv.setTextViewText(R.id.title,"FMP • "+VisibleTransfersParser.SECTIONS[section]+" ↻");
        rv.setOnClickPendingIntent(R.id.title,tabClick(ctx,widgetId,TAB,0));
        rv.setOnClickPendingIntent(R.id.previous,tabClick(ctx,widgetId,PREV,1));
        rv.setOnClickPendingIntent(R.id.next,tabClick(ctx,widgetId,NEXT,2));
        List<TransferStore.Entry> rows=new ArrayList<>();
        for(TransferStore.Entry entry:TransferStore.all(ctx)) if(entry.section==section)rows.add(entry);
        int pages=Math.max(1,(rows.size()+1)/2);
        int savedPage=ctx.getSharedPreferences(STATE,Context.MODE_PRIVATE).getInt("page_"+widgetId,0);
        int page=Math.max(0,savedPage%pages);
        int start=page*2;
        long last=TransferStore.lastCapture(ctx);
        String stamp=last==0?"non synchronisé":DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(last));
        rv.setTextViewText(R.id.status,rows.size()+" joueurs • "+(page+1)+"/"+pages+" • Lecture "+stamp);
        if(start<rows.size()) {
            rv.setTextViewText(R.id.name_one,rows.get(start).name);
            rv.setTextViewText(R.id.offer_one,rows.get(start).offer);
            rv.setOnClickPendingIntent(R.id.item_one,activityClick(ctx,widgetId,section,rows.get(start).name,3));
        }else {
            rv.setTextViewText(R.id.name_one,"Aucun joueur — gérer");
            rv.setTextViewText(R.id.offer_one,"");
            rv.setOnClickPendingIntent(R.id.item_one,activityClick(ctx,widgetId,section,null,3));
        }
        if(start+1<rows.size()) {
            rv.setTextViewText(R.id.name_two,rows.get(start+1).name);
            rv.setTextViewText(R.id.offer_two,rows.get(start+1).offer);
            rv.setOnClickPendingIntent(R.id.item_two,activityClick(ctx,widgetId,section,rows.get(start+1).name,4));
        }else {
            rv.setTextViewText(R.id.name_two,rows.size()==1?"Voir les autres dans l'app":"");
            rv.setTextViewText(R.id.offer_two,"");
            rv.setOnClickPendingIntent(R.id.item_two,activityClick(ctx,widgetId,section,null,4));
        }
        Intent openGame=new Intent(ctx,MainActivity.class).putExtra(MainActivity.EXTRA_OPEN_FMP,true)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        openGame.setData(Uri.parse("fmpwidget://game/"+widgetId));
        rv.setOnClickPendingIntent(R.id.open_fmp,PendingIntent.getActivity(ctx,widgetId*100+5,openGame,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));
        rv.setOnClickPendingIntent(R.id.manage,activityClick(ctx,widgetId,section,null,6));
        mgr.updateAppWidget(widgetId,rv);
    }
}
