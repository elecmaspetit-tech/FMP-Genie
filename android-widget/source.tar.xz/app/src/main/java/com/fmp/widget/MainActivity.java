package com.fmp.widget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;

/** Native controller for an independent FMP home-screen widget. */
public final class MainActivity extends Activity {
    static final String EXTRA_SECTION="section";
    static final String EXTRA_PLAYER="player";
    static final String EXTRA_OPEN_FMP="open_fmp";
    private static final int DARK=Color.rgb(8,32,8);
    private static final int GREEN=Color.rgb(132,203,87);
    private static final int LIGHT=Color.rgb(238,248,233);
    private int section=0;
    private LinearLayout root, entries;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        section=Math.max(0,Math.min(3,getIntent().getIntExtra(EXTRA_SECTION,0)));
        if(getIntent().getBooleanExtra(EXTRA_OPEN_FMP,false)){
            openFmp();finish();return;
        }
        drawScreen();
        String name=getIntent().getStringExtra(EXTRA_PLAYER);
        if(name!=null&&!name.isEmpty()) {
            new Handler(Looper.getMainLooper()).post(()-> {
                for(TransferStore.Entry e:TransferStore.all(this))
                    if(e.section==section && e.name.equalsIgnoreCase(name)) {showDetail(e);break;}
            });
        }
    }
    @Override protected void onResume(){super.onResume(); if(root!=null)drawScreen();}
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);setIntent(intent);
        if(intent.getBooleanExtra(EXTRA_OPEN_FMP,false)){openFmp();return;}
        section=Math.max(0,Math.min(3,intent.getIntExtra(EXTRA_SECTION,section)));
        drawScreen();
        String player=intent.getStringExtra(EXTRA_PLAYER);
        if(player!=null)for(TransferStore.Entry e:TransferStore.all(this))
            if(e.section==section && e.name.equalsIgnoreCase(player)){showDetail(e);break;}
    }
    private int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
    private TextView text(String value,int size,int color,boolean bold) {
        TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD);return t;
    }
    private LinearLayout vertical() {LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    private LinearLayout horizontal() {LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    private Button button(String label,Runnable r) {
        Button b=new Button(this);b.setText(label);b.setAllCaps(false);b.setTextSize(12);
        b.setOnClickListener(v->r.run());return b;
    }
    private void drawScreen() {
        root=vertical();root.setBackgroundColor(DARK);
        setContentView(root);
        ScrollView scroll=new ScrollView(this);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,-1));
        LinearLayout page=vertical();page.setPadding(dp(15),dp(16),dp(15),dp(28));
        scroll.addView(page);
        TextView title=text("FMP  •  MES TRANSFERTS",23,LIGHT,true);
        page.addView(title);
        TextView intro=text("Widget Android indépendant • offres de FMP lues avec votre autorisation",12,GREEN,false);
        intro.setPadding(0,dp(6),0,dp(12));page.addView(intro);
        Button pin=button("+ Ajouter le widget à l'écran d'accueil",()->{
            AppWidgetManager widgets=AppWidgetManager.getInstance(this);
            if(widgets.isRequestPinAppWidgetSupported()) {
                boolean started=widgets.requestPinAppWidget(new ComponentName(this,FavoritesWidget.class),null,null);
                if(!started)Toast.makeText(this,"Ouvrez le menu Widgets du téléphone",Toast.LENGTH_LONG).show();
            } else Toast.makeText(this,"Appui long sur l'accueil → Widgets → FMP Mes transferts",Toast.LENGTH_LONG).show();
        });
        page.addView(pin,new LinearLayout.LayoutParams(-1,dp(48)));
        LinearLayout bar=horizontal();page.addView(bar);
        for(int i=0;i<4;i++){
            final int n=i;
            Button tab=button(new String[]{"Favoris","Reçues","Mes offres","Attente"}[i],()->{section=n;drawScreen();});
            tab.setPadding(dp(3),0,dp(3),0);
            tab.setTextColor(i==section?DARK:LIGHT);
            tab.setBackgroundTintList(ColorStateList.valueOf(i==section?GREEN:0xFF31552B));
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(46),1);
            p.setMargins(dp(2),0,dp(2),0);bar.addView(tab,p);
        }
        long ts=TransferStore.lastCapture(this);
        TextView status=text(ts==0 ? "Lecture FMP : pas encore effectuée" :
            "Dernière lecture : "+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(ts)),12,0xFFBDD6AF,false);
        status.setPadding(0,dp(12),0,dp(9));page.addView(status);
        LinearLayout actions=horizontal();page.addView(actions);
        Button open=button("Ouvrir FMP",this::openFmp);
        Button perms=button("Activer lecture FMP",()->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        actions.addView(open,new LinearLayout.LayoutParams(0,dp(52),1));
        actions.addView(perms,new LinearLayout.LayoutParams(0,dp(52),1.3f));
        TextView note=text("Pour actualiser : autorisez le service « Lecture volontaire des transferts FMP », puis ouvrez dans FMP la page « Offres concernant Votre Équipe ». Faites défiler jusqu'à vos favoris. La lecture ne fonctionne que si FMP expose ses textes à Android.",12,0xFFD1DCC8,false);
        note.setPadding(0,dp(13),0,dp(18));page.addView(note);
        LinearLayout listTitle=horizontal();page.addView(listTitle);
        TextView label=text(VisibleTransfersParser.SECTIONS[section],20,LIGHT,true);
        listTitle.addView(label,new LinearLayout.LayoutParams(0,-2,1));
        Button add=button("+ Ajouter",()->showEdit(null));
        listTitle.addView(add);
        entries=vertical();entries.setPadding(0,dp(6),0,0);page.addView(entries);
        List<TransferStore.Entry> all=TransferStore.all(this);
        int count=0;
        for(TransferStore.Entry entry:all)if(entry.section==section){addEntry(entry);count++;}
        if(count==0){
            TextView empty=text("Aucun joueur reconnu dans cette catégorie.\nActivez la lecture, ouvrez la page des transferts dans FMP ou ajoutez un favori manuellement.",14,0xFFC8DCC1,false);
            empty.setPadding(dp(10),dp(22),dp(10),dp(20));entries.addView(empty);
        }
        Button diagnostic=button("Diagnostic de lecture FMP",this::showDiagnostic);
        LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,dp(50));dp.topMargin=dp(20);page.addView(diagnostic,dp);
        TextView privacy=text("Confidentialité : stockage local uniquement. Aucun identifiant FMP n'est demandé. Aucune enchère n'est envoyée depuis ce widget. Les montants proposés ici sont des brouillons à confirmer dans FMP.",12,0xFF9EB394,false);
        privacy.setPadding(dp(4),dp(13),dp(4),dp(6));page.addView(privacy);
    }
    private void addEntry(TransferStore.Entry e) {
        LinearLayout card=vertical();card.setPadding(dp(12),dp(12),dp(12),dp(10));card.setBackgroundColor(0xFF17420E);
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.bottomMargin=dp(9);entries.addView(card,cp);
        TextView name=text(e.name,17,LIGHT,true);card.addView(name);
        String offer=e.offer.isEmpty()?"Offre non relevée":"Offre : "+e.offer;
        String deadline=e.deadline.isEmpty()?"":"  •  Fin : "+e.deadline;
        TextView details=text(offer+deadline,13,GREEN,false);details.setPadding(0,dp(5),0,dp(5));card.addView(details);
        String stamp=e.updated==0?"Ajout manuel":DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(e.updated));
        card.addView(text("Source : "+e.source+" · "+stamp,11,0xFFBFD3B6,false));
        if(!e.draft.isEmpty())card.addView(text("Brouillon d'enchère : "+e.draft,12,0xFFFBE4A5,true));
        LinearLayout controls=horizontal();card.addView(controls);
        controls.addView(button("Détails",()->showDetail(e)),new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("Modifier",()->showEdit(e)),new LinearLayout.LayoutParams(0,dp(42),1));
        controls.addView(button("FMP ↗",this::openFmp),new LinearLayout.LayoutParams(0,dp(42),1));
    }
    private void showDetail(TransferStore.Entry e) {
        String message="Catégorie : "+VisibleTransfersParser.SECTIONS[e.section]+"\n"
            +"Offre affichée : "+(e.offer.isEmpty()?"non connue":e.offer)+"\n"
            +"Fin : "+(e.deadline.isEmpty()?"non connue":e.deadline)+"\n"
            +"Brouillon : "+(e.draft.isEmpty()?"aucun":e.draft)+"\n\n"
            +"Le widget ne réalise pas d'enchère. Toute opération réelle doit être confirmée dans FMP.";
        new AlertDialog.Builder(this).setTitle(e.name).setMessage(message)
            .setPositiveButton("Ouvrir FMP",(d,w)->openFmp())
            .setNeutralButton("Préparer une offre",(d,w)->showDraft(e))
            .setNegativeButton("Fermer",null).show();
    }
    private void showDraft(TransferStore.Entry e) {
        EditText field=new EditText(this);field.setSingleLine();field.setHint("Montant à saisir ensuite dans FMP");
        field.setInputType(InputType.TYPE_CLASS_NUMBER);field.setText(e.draft);
        new AlertDialog.Builder(this).setTitle("Brouillon pour "+e.name).setView(field)
            .setPositiveButton("Conserver le brouillon",(d,w)->{
                String number=field.getText().toString().trim();
                if(number.length()>18){Toast.makeText(this,"Montant trop long",Toast.LENGTH_SHORT).show();return;}
                e.draft=number;TransferStore.upsert(this,e);drawScreen();
            }).setNegativeButton("Annuler",null).show();
    }
    private EditText input(String hint,String initial) {
        EditText e=new EditText(this);e.setSingleLine();e.setText(initial);
        e.setHint(hint);e.setTextSize(15);return e;
    }
    private void showEdit(TransferStore.Entry existing) {
        LinearLayout form=vertical();form.setPadding(dp(18),dp(8),dp(18),0);
        EditText name=input("Nom du joueur",existing==null?"":existing.name);
        EditText bid=input("Offre affichée",existing==null?"":existing.offer);
        EditText deadline=input("Fin d'enchère (texte)",existing==null?"":existing.deadline);
        form.addView(name);form.addView(bid);form.addView(deadline);
        AlertDialog.Builder b=new AlertDialog.Builder(this).setTitle(existing==null?"Ajouter un joueur":"Modifier un joueur")
            .setView(form).setPositiveButton("Enregistrer",(d,w)->{
                String n=name.getText().toString().trim();
                if(n.isEmpty()||n.length()>65){Toast.makeText(this,"Nom invalide",Toast.LENGTH_SHORT).show();return;}
                if(existing!=null&&!existing.name.equalsIgnoreCase(n))TransferStore.remove(this,existing.section,existing.name);
                TransferStore.upsert(this,new TransferStore.Entry(section,n,
                    bid.getText().toString().trim(),deadline.getText().toString().trim(),
                    existing==null?"":existing.draft,System.currentTimeMillis(),"manuel"));
                drawScreen();
            }).setNegativeButton("Annuler",null);
        if(existing!=null)b.setNeutralButton("Supprimer",(d,w)->new AlertDialog.Builder(this)
            .setTitle("Supprimer "+existing.name+" ?")
            .setPositiveButton("Supprimer",(d2,w2)->{TransferStore.remove(this,existing.section,existing.name);drawScreen();})
            .setNegativeButton("Annuler",null).show());
        b.show();
    }
    private void showDiagnostic(){
        TextView text=text(TransferStore.diagnostic(this),12,Color.BLACK,false);
        text.setTextIsSelectable(true);text.setPadding(dp(12),dp(12),dp(12),dp(12));
        ScrollView scroll=new ScrollView(this);scroll.addView(text);
        new AlertDialog.Builder(this).setTitle("Diagnostic local FMP")
            .setView(scroll).setPositiveButton("Fermer",null).show();
    }
    private void openFmp() {
        try {
            Intent launch=getPackageManager().getLaunchIntentForPackage("com.ledev.fmp.mobile");
            if(launch==null){
                new AlertDialog.Builder(this).setTitle("FMP non détecté")
                    .setMessage("Installez ou ouvrez l'APK officiel FMP. Aucun lien profond vers la page des favoris n'a été vérifié.")
                    .setPositiveButton("Fermer",null).show();return;
            }
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
        }catch(Exception e){Toast.makeText(this,"Impossible d'ouvrir FMP sur cet appareil",Toast.LENGTH_LONG).show();}
    }
}
